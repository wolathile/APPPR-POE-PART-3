﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DisasterAlleviationFoundation.Data;
using DisasterAlleviationFoundation.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace DisasterAlleviationFoundation.Controllers
{
    [Authorize]
    public class DonationController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DonationController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Donation
        public async Task<IActionResult> Index()
        {
            var donations = await _context.Donations
                .OrderByDescending(d => d.DateDonated)
                .ToListAsync();
            return View(donations);
        }

        // GET: Donation/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var donation = await _context.Donations
                .FirstOrDefaultAsync(m => m.DonationId == id);

            if (donation == null)
            {
                return NotFound();
            }

            return View(donation);
        }

        // GET: Donation/Create
        public IActionResult Create()
        {
            ViewBag.Incidents = new SelectList(_context.DisasterIncidents
                .Where(i => i.Status != "Resolved")
                .OrderByDescending(i => i.DateReported), "IncidentId", "Location");

            return View();
        }

        // POST: Donation/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DonationType,Description,Quantity,MonetaryAmount,DonorName,DonorEmail,ContactNumber,AllocatedToIncidentId,IsAnonymous")] Donation donation)
        {
            if (ModelState.IsValid)
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                donation.DonorUserId = userId ?? string.Empty;
                donation.DateDonated = DateTime.Now;
                donation.Status = "Received";

                _context.Add(donation);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Thank you for your generous donation!";
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Incidents = new SelectList(_context.DisasterIncidents
                .Where(i => i.Status != "Resolved")
                .OrderByDescending(i => i.DateReported), "IncidentId", "Location");

            return View(donation);
        }

        // GET: Donation/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var donation = await _context.Donations.FindAsync(id);
            if (donation == null)
            {
                return NotFound();
            }

            ViewBag.Incidents = new SelectList(_context.DisasterIncidents
                .Where(i => i.Status != "Resolved")
                .OrderByDescending(i => i.DateReported), "IncidentId", "Location", donation.AllocatedToIncidentId);

            return View(donation);
        }

        // POST: Donation/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("DonationId,DonationType,Description,Quantity,MonetaryAmount,DonorName,DonorEmail,ContactNumber,Status,AllocatedToIncidentId,IsAnonymous")] Donation donation)
        {
            if (id != donation.DonationId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var existingDonation = await _context.Donations.FindAsync(id);

                    if (existingDonation == null)
                    {
                        return NotFound();
                    }

                    existingDonation.DonationType = donation.DonationType;
                    existingDonation.Description = donation.Description;
                    existingDonation.Quantity = donation.Quantity;
                    existingDonation.MonetaryAmount = donation.MonetaryAmount;
                    existingDonation.DonorName = donation.DonorName;
                    existingDonation.DonorEmail = donation.DonorEmail;
                    existingDonation.ContactNumber = donation.ContactNumber;
                    existingDonation.Status = donation.Status;
                    existingDonation.AllocatedToIncidentId = donation.AllocatedToIncidentId;
                    existingDonation.IsAnonymous = donation.IsAnonymous;

                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Donation updated successfully!";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DonationExists(donation.DonationId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Incidents = new SelectList(_context.DisasterIncidents
                .Where(i => i.Status != "Resolved")
                .OrderByDescending(i => i.DateReported), "IncidentId", "Location", donation.AllocatedToIncidentId);

            return View(donation);
        }

        // GET: Donation/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var donation = await _context.Donations
                .FirstOrDefaultAsync(m => m.DonationId == id);

            if (donation == null)
            {
                return NotFound();
            }

            return View(donation);
        }

        // POST: Donation/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var donation = await _context.Donations.FindAsync(id);

            if (donation != null)
            {
                _context.Donations.Remove(donation);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Donation record deleted successfully!";
            }

            return RedirectToAction(nameof(Index));
        }

        // Helper method to check if donation exists
        private bool DonationExists(int id)
        {
            return _context.Donations.Any(e => e.DonationId == id);
        }

        // GET: Donation/MyDonations
        public async Task<IActionResult> MyDonations()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var donations = await _context.Donations
                .Where(d => d.DonorUserId == userId)
                .OrderByDescending(d => d.DateDonated)
                .ToListAsync();

            return View(donations);
        }
    }
}