﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DisasterAlleviationFoundation.Data;
using DisasterAlleviationFoundation.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DisasterAlleviationFoundation.Controllers
{
    [Authorize]
    public class VolunteerController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VolunteerController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Volunteer
        public async Task<IActionResult> Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (userId == null)
            {
                return RedirectToAction(nameof(Register));
            }

            var volunteer = await _context.Volunteers
                .FirstOrDefaultAsync(v => v.UserId == userId);

            if (volunteer == null)
            {
                return RedirectToAction(nameof(Register));
            }

            return View(volunteer);
        }

        // GET: Volunteer/Register
        public IActionResult Register()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var existingVolunteer = _context.Volunteers
                .FirstOrDefault(v => v.UserId == userId);

            if (existingVolunteer != null)
            {
                TempData["InfoMessage"] = "You are already registered as a volunteer!";
                return RedirectToAction(nameof(Index));
            }

            var volunteer = new Volunteer
            {
                Email = User.FindFirstValue(ClaimTypes.Email) ?? string.Empty
            };

            return View(volunteer);
        }

        // POST: Volunteer/Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register([Bind("FullName,Email,PhoneNumber,Address,DateOfBirth,Skills,Availability,EmergencyContactName,EmergencyContactNumber")] Volunteer volunteer)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (ModelState.IsValid)
            {
                volunteer.UserId = userId;
                volunteer.RegistrationDate = DateTime.Now;
                volunteer.IsActive = true;

                _context.Add(volunteer);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Successfully registered as a volunteer!";
                return RedirectToAction(nameof(Tasks));
            }
            return View(volunteer);
        }

        // GET: Volunteer/Edit
        public async Task<IActionResult> Edit()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var volunteer = await _context.Volunteers
                .FirstOrDefaultAsync(v => v.UserId == userId);

            if (volunteer == null)
            {
                return RedirectToAction(nameof(Register));
            }

            return View(volunteer);
        }

        // POST: Volunteer/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("VolunteerId,FullName,Email,PhoneNumber,Address,DateOfBirth,Skills,Availability,IsActive,EmergencyContactName,EmergencyContactNumber")] Volunteer volunteer)
        {
            if (id != volunteer.VolunteerId)
            {
                return NotFound();
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var existingVolunteer = await _context.Volunteers.FindAsync(id);

            if (existingVolunteer == null)
            {
                return NotFound();
            }

            if (existingVolunteer.UserId != userId)
            {
                return Forbid();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    existingVolunteer.FullName = volunteer.FullName;
                    existingVolunteer.Email = volunteer.Email;
                    existingVolunteer.PhoneNumber = volunteer.PhoneNumber;
                    existingVolunteer.Address = volunteer.Address;
                    existingVolunteer.DateOfBirth = volunteer.DateOfBirth;
                    existingVolunteer.Skills = volunteer.Skills;
                    existingVolunteer.Availability = volunteer.Availability;
                    existingVolunteer.IsActive = volunteer.IsActive;
                    existingVolunteer.EmergencyContactName = volunteer.EmergencyContactName;
                    existingVolunteer.EmergencyContactNumber = volunteer.EmergencyContactNumber;

                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Profile updated successfully!";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!VolunteerExists(volunteer.VolunteerId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(volunteer);
        }

        // GET: Volunteer/Tasks
        public async Task<IActionResult> Tasks()
        {
            var tasks = await _context.VolunteerTasks
                .Where(t => t.Status == "Open" || t.Status == "In Progress")
                .OrderBy(t => t.StartDate)
                .ToListAsync();

            return View(tasks);
        }

        // GET: Volunteer/MyTasks
        public async Task<IActionResult> MyTasks()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var volunteer = await _context.Volunteers
                .FirstOrDefaultAsync(v => v.UserId == userId);

            if (volunteer == null)
            {
                return RedirectToAction(nameof(Register));
            }

            var assignments = await _context.VolunteerAssignments
                .Include(a => a.Task)
                .Where(a => a.VolunteerId == volunteer.VolunteerId)
                .OrderByDescending(a => a.DateAssigned)
                .ToListAsync();

            return View(assignments);
        }

        // POST: Volunteer/AssignTask
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AssignTask(int taskId)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (userId == null)
            {
                TempData["ErrorMessage"] = "Please login first!";
                return RedirectToAction("Login", "Account");
            }

            var volunteer = await _context.Volunteers
                .FirstOrDefaultAsync(v => v.UserId == userId);

            if (volunteer == null)
            {
                TempData["ErrorMessage"] = "Please register as a volunteer first!";
                return RedirectToAction(nameof(Register));
            }

            var task = await _context.VolunteerTasks.FindAsync(taskId);
            if (task == null)
            {
                return NotFound();
            }

            var existingAssignment = await _context.VolunteerAssignments
                .FirstOrDefaultAsync(a => a.VolunteerId == volunteer.VolunteerId && a.TaskId == taskId);

            if (existingAssignment != null)
            {
                TempData["InfoMessage"] = "You are already assigned to this task!";
                return RedirectToAction(nameof(Tasks));
            }

            if (task.AssignedVolunteers >= task.RequiredVolunteers)
            {
                TempData["ErrorMessage"] = "This task already has enough volunteers!";
                return RedirectToAction(nameof(Tasks));
            }

            var assignment = new VolunteerAssignment
            {
                VolunteerId = volunteer.VolunteerId,
                TaskId = taskId,
                DateAssigned = DateTime.Now,
                Status = "Assigned"
            };

            _context.VolunteerAssignments.Add(assignment);
            task.AssignedVolunteers++;

            if (task.AssignedVolunteers >= task.RequiredVolunteers)
            {
                task.Status = "In Progress";
            }

            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Successfully assigned to task!";
            return RedirectToAction(nameof(MyTasks));
        }

        // POST: Volunteer/CompleteTask
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CompleteTask(int assignmentId, decimal hours, string? notes)
        {
            var assignment = await _context.VolunteerAssignments
                .Include(a => a.Volunteer)
                .FirstOrDefaultAsync(a => a.AssignmentId == assignmentId);

            if (assignment == null || assignment.Volunteer == null)
            {
                return NotFound();
            }

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (userId == null || assignment.Volunteer.UserId != userId)
            {
                return Forbid();
            }

            assignment.Status = "Completed";
            assignment.CompletionDate = DateTime.Now;
            assignment.HoursContributed = hours;
            assignment.Notes = notes;

            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Task marked as completed!";
            return RedirectToAction(nameof(MyTasks));
        }

        private bool VolunteerExists(int id)
        {
            return _context.Volunteers.Any(e => e.VolunteerId == id);
        }
    }
}