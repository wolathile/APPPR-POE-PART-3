﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using DisasterAlleviationFoundation.Data;
using DisasterAlleviationFoundation.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DisasterAlleviationFoundation.Controllers
{
    [Authorize]
    public class DisasterIncidentController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DisasterIncidentController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: DisasterIncident
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            var incidents = await _context.DisasterIncidents
                .OrderByDescending(i => i.DateReported)
                .ToListAsync();
            return View(incidents);
        }

        // GET: DisasterIncident/Details/5
        [AllowAnonymous]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var incident = await _context.DisasterIncidents
                .FirstOrDefaultAsync(m => m.IncidentId == id);

            if (incident == null)
            {
                return NotFound();
            }

            return View(incident);
        }

        // GET: DisasterIncident/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: DisasterIncident/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IncidentType,Location,Description,SeverityLevel,PeopleAffected,ContactNumber")] DisasterIncident incident)
        {
            if (ModelState.IsValid)
            {
                incident.ReportedByUserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                incident.DateReported = DateTime.Now;
                incident.Status = "Pending";

                _context.Add(incident);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Incident reported successfully!";
                return RedirectToAction(nameof(Index));
            }
            return View(incident);
        }

        // GET: DisasterIncident/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var incident = await _context.DisasterIncidents.FindAsync(id);
            if (incident == null)
            {
                return NotFound();
            }

            // Only allow editing by the user who reported it
            if (incident.ReportedByUserId != User.FindFirstValue(ClaimTypes.NameIdentifier))
            {
                return Forbid();
            }

            return View(incident);
        }

        // POST: DisasterIncident/Edit/5
        // POST: DisasterIncident/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IncidentId,IncidentType,Location,Description,SeverityLevel,PeopleAffected,ContactNumber,Status")] DisasterIncident incident)
        {
            if (id != incident.IncidentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var existingIncident = await _context.DisasterIncidents.FindAsync(id);

                    if (existingIncident == null)
                    {
                        return NotFound();
                    }

                    if (existingIncident.ReportedByUserId != User.FindFirstValue(ClaimTypes.NameIdentifier))
                    {
                        return Forbid();
                    }

                    existingIncident.IncidentType = incident.IncidentType;
                    existingIncident.Location = incident.Location;
                    existingIncident.Description = incident.Description;
                    existingIncident.SeverityLevel = incident.SeverityLevel;
                    existingIncident.PeopleAffected = incident.PeopleAffected;
                    existingIncident.ContactNumber = incident.ContactNumber;
                    existingIncident.Status = incident.Status;

                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Incident updated successfully!";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!IncidentExists(incident.IncidentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(incident);
        }
        // GET: DisasterIncident/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var incident = await _context.DisasterIncidents
                .FirstOrDefaultAsync(m => m.IncidentId == id);

            if (incident == null)
            {
                return NotFound();
            }

            if (incident.ReportedByUserId != User.FindFirstValue(ClaimTypes.NameIdentifier))
            {
                return Forbid();
            }

            return View(incident);
        }

        // POST: DisasterIncident/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var incident = await _context.DisasterIncidents.FindAsync(id);
            if (incident.ReportedByUserId != User.FindFirstValue(ClaimTypes.NameIdentifier))
            {
                return Forbid();
            }

            _context.DisasterIncidents.Remove(incident);
            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = "Incident deleted successfully!";
            return RedirectToAction(nameof(Index));
        }

        private bool IncidentExists(int id)
        {
            return _context.DisasterIncidents.Any(e => e.IncidentId == id);
        }
    }
}