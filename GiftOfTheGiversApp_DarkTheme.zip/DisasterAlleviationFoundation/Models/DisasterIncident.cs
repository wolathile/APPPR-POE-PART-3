﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models
{
    public class DisasterIncident
    {
        [Key]
        public int IncidentId { get; set; }

        [Required(ErrorMessage = "Incident type is required")]
        [Display(Name = "Incident Type")]
        public string IncidentType { get; set; } = string.Empty;

        [Required(ErrorMessage = "Location is required")]
        [StringLength(200)]
        public string Location { get; set; } = string.Empty;

        [Required(ErrorMessage = "Description is required")]
        [StringLength(1000)]
        [DataType(DataType.MultilineText)]
        public string Description { get; set; } = string.Empty;

        [Display(Name = "Date Reported")]
        public DateTime DateReported { get; set; } = DateTime.Now;

        [Display(Name = "Severity Level")]
        [Range(1, 5, ErrorMessage = "Severity must be between 1 and 5")]
        public int SeverityLevel { get; set; }

        [Display(Name = "Number of People Affected")]
        public int? PeopleAffected { get; set; }

        public string Status { get; set; } = "Pending";

        public string ReportedByUserId { get; set; } = string.Empty;

        [Display(Name = "Contact Number")]
        [Phone]
        public string ContactNumber { get; set; } = string.Empty;
    }
}