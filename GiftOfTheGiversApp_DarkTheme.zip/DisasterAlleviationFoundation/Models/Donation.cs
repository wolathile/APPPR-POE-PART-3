﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DisasterAlleviationFoundation.Models
{
    public class Donation
    {
        [Key]
        public int DonationId { get; set; }

        [Required(ErrorMessage = "Donation type is required")]
        [Display(Name = "Donation Type")]
        public string DonationType { get; set; } = string.Empty;

        [Required(ErrorMessage = "Description is required")]
        [StringLength(500)]
        public string Description { get; set; } = string.Empty;

        [Display(Name = "Quantity")]
        public int? Quantity { get; set; }

        [Display(Name = "Monetary Amount")]
        [Column(TypeName = "decimal(18, 2)")]
        [DataType(DataType.Currency)]
        public decimal? MonetaryAmount { get; set; }

        [Required(ErrorMessage = "Donor name is required")]
        [Display(Name = "Donor Name")]
        [StringLength(100)]
        public string DonorName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress]
        [Display(Name = "Email Address")]
        public string DonorEmail { get; set; } = string.Empty;

        [Phone]
        [Display(Name = "Contact Number")]
        public string? ContactNumber { get; set; }

        [Display(Name = "Date Donated")]
        public DateTime DateDonated { get; set; } = DateTime.Now;

        public string Status { get; set; } = "Received";

        [Display(Name = "Allocated To Incident")]
        public int? AllocatedToIncidentId { get; set; }

        public string DonorUserId { get; set; } = string.Empty;

        [Display(Name = "Is Anonymous")]
        public bool IsAnonymous { get; set; } = false;
    }
}