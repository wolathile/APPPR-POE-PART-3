﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DisasterAlleviationFoundation.Models
{
    public class VolunteerAssignment
    {
        [Key]
        public int AssignmentId { get; set; }

        [Required]
        public int VolunteerId { get; set; }

        [Required]
        public int TaskId { get; set; }

        [Display(Name = "Date Assigned")]
        public DateTime DateAssigned { get; set; } = DateTime.Now;

        public string Status { get; set; } = "Assigned";

        [Display(Name = "Completion Date")]
        public DateTime? CompletionDate { get; set; }

        [Display(Name = "Hours Contributed")]
        public decimal? HoursContributed { get; set; }

        [Display(Name = "Notes")]
        [StringLength(500)]
        public string? Notes { get; set; }

        // Navigation properties
        public Volunteer? Volunteer { get; set; }
        public VolunteerTask? Task { get; set; }
    }
}