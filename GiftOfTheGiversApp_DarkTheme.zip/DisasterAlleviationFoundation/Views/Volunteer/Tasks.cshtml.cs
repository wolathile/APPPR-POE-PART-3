using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterAlleviationFoundation.Views.Volunteer
{
    public class TasksModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
