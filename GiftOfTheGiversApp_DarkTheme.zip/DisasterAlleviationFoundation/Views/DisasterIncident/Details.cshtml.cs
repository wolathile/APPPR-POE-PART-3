using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterAlleviationFoundation.Views.DisasterIncident
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
