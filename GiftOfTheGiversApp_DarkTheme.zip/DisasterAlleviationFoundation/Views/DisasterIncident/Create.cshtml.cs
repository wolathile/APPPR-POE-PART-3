using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterAlleviationFoundation.Views.DisasterIncident
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
