using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterAlleviationFoundation.Views.Donation
{
    public class MyDonationsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
