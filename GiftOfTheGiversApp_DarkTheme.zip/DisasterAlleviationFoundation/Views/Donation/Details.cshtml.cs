using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterAlleviationFoundation.Views.Donation
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
