﻿using DisasterAlleviationFoundation.Data;
using DisasterAlleviationFoundation.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace DisasterAlleviationFoundation.Services
{
    public static class SeedData
    {
        public static void Initialize(ApplicationDbContext context)
        {
            context.Database.Migrate();

            // Check if we already have tasks
            if (context.VolunteerTasks.Any())
            {
                return; // Database has been seeded
            }

            // Add sample volunteer tasks
            var tasks = new VolunteerTask[]
            {
                new VolunteerTask
                {
                    TaskName = "Emergency Food Distribution",
                    Description = "Help distribute food packages to families affected by recent floods. Tasks include sorting, packing, and distributing food items.",
                    Location = "Community Center, Johannesburg",
                    StartDate = DateTime.Now.AddDays(2),
                    EndDate = DateTime.Now.AddDays(2).AddHours(6),
                    RequiredVolunteers = 10,
                    AssignedVolunteers = 0,
                    Status = "Open",
                    CreatedDate = DateTime.Now
                },
                new VolunteerTask
                {
                    TaskName = "Medical Supply Organization",
                    Description = "Organize and categorize medical supplies for disaster relief. No medical training required.",
                    Location = "Red Cross Center, Pretoria",
                    StartDate = DateTime.Now.AddDays(3),
                    EndDate = DateTime.Now.AddDays(3).AddHours(4),
                    RequiredVolunteers = 5,
                    AssignedVolunteers = 0,
                    Status = "Open",
                    CreatedDate = DateTime.Now
                },
                new VolunteerTask
                {
                    TaskName = "Shelter Setup and Maintenance",
                    Description = "Help set up temporary shelters for displaced families. Tasks include assembling tents, organizing supplies, and general maintenance.",
                    Location = "Relief Camp, Durban",
                    StartDate = DateTime.Now.AddDays(1),
                    EndDate = DateTime.Now.AddDays(5),
                    RequiredVolunteers = 15,
                    AssignedVolunteers = 0,
                    Status = "Open",
                    CreatedDate = DateTime.Now
                },
                new VolunteerTask
                {
                    TaskName = "Community Cleanup Drive",
                    Description = "Join our team in cleaning up areas affected by recent storms. Bring work gloves and wear comfortable clothing.",
                    Location = "Coastal Area, Cape Town",
                    StartDate = DateTime.Now.AddDays(4),
                    EndDate = DateTime.Now.AddDays(4).AddHours(5),
                    RequiredVolunteers = 20,
                    AssignedVolunteers = 0,
                    Status = "Open",
                    CreatedDate = DateTime.Now
                },
                new VolunteerTask
                {
                    TaskName = "Donation Sorting and Cataloging",
                    Description = "Help sort through donations of clothing, blankets, and household items. Organize items by category and size.",
                    Location = "Warehouse, Port Elizabeth",
                    StartDate = DateTime.Now.AddDays(1),
                    EndDate = DateTime.Now.AddDays(1).AddHours(8),
                    RequiredVolunteers = 8,
                    AssignedVolunteers = 0,
                    Status = "Open",
                    CreatedDate = DateTime.Now
                },
                new VolunteerTask
                {
                    TaskName = "Emergency Hotline Support",
                    Description = "Answer calls from people affected by disasters and provide information about available resources. Training will be provided.",
                    Location = "Call Center, Johannesburg",
                    StartDate = DateTime.Now.AddDays(2),
                    EndDate = DateTime.Now.AddDays(7),
                    RequiredVolunteers = 6,
                    AssignedVolunteers = 0,
                    Status = "Open",
                    CreatedDate = DateTime.Now
                },
                new VolunteerTask
                {
                    TaskName = "Children's Activity Coordinator",
                    Description = "Organize games and activities for children in temporary shelters. Help keep children engaged and entertained.",
                    Location = "Family Shelter, Bloemfontein",
                    StartDate = DateTime.Now.AddDays(3),
                    EndDate = DateTime.Now.AddDays(3).AddHours(4),
                    RequiredVolunteers = 4,
                    AssignedVolunteers = 0,
                    Status = "Open",
                    CreatedDate = DateTime.Now
                },
                new VolunteerTask
                {
                    TaskName = "Transportation Assistance",
                    Description = "Help transport supplies and affected families to relief centers. Valid driver's license required.",
                    Location = "Various Locations, Gauteng",
                    StartDate = DateTime.Now.AddDays(1),
                    EndDate = DateTime.Now.AddDays(10),
                    RequiredVolunteers = 12,
                    AssignedVolunteers = 0,
                    Status = "Open",
                    CreatedDate = DateTime.Now
                },
                new VolunteerTask
                {
                    TaskName = "Data Entry and Documentation",
                    Description = "Help maintain records of donations, volunteers, and relief activities. Basic computer skills required.",
                    Location = "Administrative Office, Johannesburg",
                    StartDate = DateTime.Now.AddDays(2),
                    EndDate = DateTime.Now.AddDays(14),
                    RequiredVolunteers = 3,
                    AssignedVolunteers = 0,
                    Status = "Open",
                    CreatedDate = DateTime.Now
                },
                new VolunteerTask
                {
                    TaskName = "First Aid Support Team",
                    Description = "Provide basic first aid support at relief centers. First aid certification preferred but not required.",
                    Location = "Relief Center, Pietermaritzburg",
                    StartDate = DateTime.Now.AddDays(1),
                    EndDate = DateTime.Now.AddDays(7),
                    RequiredVolunteers = 7,
                    AssignedVolunteers = 0,
                    Status = "Open",
                    CreatedDate = DateTime.Now
                }
            };

            foreach (var task in tasks)
            {
                context.VolunteerTasks.Add(task);
            }

            context.SaveChanges();

            // Add sample incidents
            if (!context.DisasterIncidents.Any())
            {
                var incidents = new DisasterIncident[]
                {
                    new DisasterIncident
                    {
                        IncidentType = "Flood",
                        Location = "Durban, KwaZulu-Natal",
                        Description = "Heavy rainfall has caused severe flooding in residential areas. Many families have been displaced and roads are impassable.",
                        DateReported = DateTime.Now.AddDays(-5),
                        SeverityLevel = 5,
                        PeopleAffected = 500,
                        Status = "In Progress",
                        ReportedByUserId = "system",
                        ContactNumber = "+27 31 123 4567"
                    },
                    new DisasterIncident
                    {
                        IncidentType = "Fire",
                        Location = "Informal Settlement, Cape Town",
                        Description = "Large fire has destroyed multiple homes. Immediate assistance needed for displaced families.",
                        DateReported = DateTime.Now.AddDays(-3),
                        SeverityLevel = 4,
                        PeopleAffected = 200,
                        Status = "In Progress",
                        ReportedByUserId = "system",
                        ContactNumber = "+27 21 987 6543"
                    },
                    new DisasterIncident
                    {
                        IncidentType = "Storm",
                        Location = "Coastal Areas, Port Elizabeth",
                        Description = "Severe storm has caused damage to homes and infrastructure. Power outages affecting the area.",
                        DateReported = DateTime.Now.AddDays(-2),
                        SeverityLevel = 3,
                        PeopleAffected = 150,
                        Status = "Pending",
                        ReportedByUserId = "system",
                        ContactNumber = "+27 41 555 7890"
                    }
                };

                foreach (var incident in incidents)
                {
                    context.DisasterIncidents.Add(incident);
                }

                context.SaveChanges();
            }
        }
    }
}