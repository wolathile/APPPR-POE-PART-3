﻿using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Xunit;
using Xunit.Abstractions;

namespace DisasterAlleviationFoundation.UITests.UITests
{
    public class BasicUITests : IDisposable
    {
        private readonly IWebDriver _driver;
        private readonly ITestOutputHelper _output;
        private const string BASE_URL = "https://localhost:7165;http://localhost:5045"; 

        public BasicUITests(ITestOutputHelper output)
        {
            _output = output;

            var options = new ChromeOptions();
            // Remove headless for now so you can see what's happening
            // options.AddArgument("--headless");
            options.AddArgument("--no-sandbox");
            options.AddArgument("--disable-dev-shm-usage");
            options.AddArgument("--ignore-certificate-errors");

            _driver = new ChromeDriver(options);
            _driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            _driver.Manage().Window.Maximize();
        }

        [Fact]
        public void Test01_HomePage_LoadsSuccessfully()
        {
            try
            {
                // Act
                _output.WriteLine($"Navigating to: {BASE_URL}");
                _driver.Navigate().GoToUrl(BASE_URL);

                Thread.Sleep(2000); // Wait for page to load

                // Assert
                _output.WriteLine($"✅ Page Title: {_driver.Title}");
                _output.WriteLine($"✅ Current URL: {_driver.Url}");
                _output.WriteLine($"✅ Page Source Length: {_driver.PageSource.Length}");

                Assert.NotNull(_driver.Title);
                Assert.NotEmpty(_driver.Title);
            }
            catch (Exception ex)
            {
                _output.WriteLine($"❌ ERROR: {ex.Message}");
                throw;
            }
        }

        [Fact]
        public void Test02_HomePage_HasTitle()
        {
            try
            {
                // Act
                _driver.Navigate().GoToUrl(BASE_URL);
                Thread.Sleep(2000);

                // Assert
                var title = _driver.Title;
                _output.WriteLine($"✅ Page Title: {title}");

                Assert.False(string.IsNullOrEmpty(title));
                Assert.Contains("Disaster", title, StringComparison.OrdinalIgnoreCase);
            }
            catch (Exception ex)
            {
                _output.WriteLine($"❌ ERROR: {ex.Message}");
                throw;
            }
        }

        [Fact]
        public void Test03_HomePage_HasNavigationBar()
        {
            try
            {
                // Arrange
                _driver.Navigate().GoToUrl(BASE_URL);
                Thread.Sleep(2000);

                // Act
                var navBars = _driver.FindElements(By.TagName("nav"));

                // Assert
                _output.WriteLine($"✅ Found {navBars.Count} navigation bars");
                Assert.True(navBars.Count > 0, "Page should have a navigation bar");
            }
            catch (Exception ex)
            {
                _output.WriteLine($"❌ ERROR: {ex.Message}");
                throw;
            }
        }

        [Fact]
        public void Test04_HomePage_HasHomeLink()
        {
            try
            {
                // Arrange
                _driver.Navigate().GoToUrl(BASE_URL);
                Thread.Sleep(2000);

                // Act - Try multiple ways to find home link
                IWebElement homeLink = null;

                try
                {
                    homeLink = _driver.FindElement(By.LinkText("Home"));
                }
                catch
                {
                    try
                    {
                        homeLink = _driver.FindElement(By.PartialLinkText("Home"));
                    }
                    catch
                    {
                        _output.WriteLine("⚠️ Home link not found - checking for any links");
                        var allLinks = _driver.FindElements(By.TagName("a"));
                        _output.WriteLine($"Found {allLinks.Count} total links on page");
                    }
                }

                // Assert
                if (homeLink != null)
                {
                    _output.WriteLine("✅ Home link found and visible");
                    Assert.True(homeLink.Displayed);
                }
                else
                {
                    _output.WriteLine("⚠️ Test informational - no home link found");
                }
            }
            catch (Exception ex)
            {
                _output.WriteLine($"⚠️ Non-critical: {ex.Message}");
            }
        }

        [Fact]
        public void Test05_HomePage_HasContent()
        {
            try
            {
                // Arrange
                _driver.Navigate().GoToUrl(BASE_URL);
                Thread.Sleep(2000);

                // Act
                var bodyElement = _driver.FindElement(By.TagName("body"));
                var bodyText = bodyElement.Text;

                // Assert
                _output.WriteLine($"✅ Page has {bodyText.Length} characters of content");
                Assert.True(bodyText.Length > 100, "Page should have substantial content");
            }
            catch (Exception ex)
            {
                _output.WriteLine($"❌ ERROR: {ex.Message}");
                throw;
            }
        }

        [Fact]
        public void Test06_HomePage_ResponsiveDesign_Desktop()
        {
            try
            {
                // Arrange - Set desktop size
                _driver.Manage().Window.Size = new System.Drawing.Size(1920, 1080);
                _driver.Navigate().GoToUrl(BASE_URL);
                Thread.Sleep(2000);

                // Act
                var body = _driver.FindElement(By.TagName("body"));

                // Assert
                _output.WriteLine("✅ Page renders on desktop viewport (1920x1080)");
                Assert.NotNull(body);
            }
            catch (Exception ex)
            {
                _output.WriteLine($"❌ ERROR: {ex.Message}");
                throw;
            }
        }

        [Fact]
        public void Test07_HomePage_ResponsiveDesign_Tablet()
        {
            try
            {
                // Arrange - Set tablet size
                _driver.Manage().Window.Size = new System.Drawing.Size(768, 1024);
                _driver.Navigate().GoToUrl(BASE_URL);
                Thread.Sleep(2000);

                // Act
                var body = _driver.FindElement(By.TagName("body"));

                // Assert
                _output.WriteLine("✅ Page renders on tablet viewport (768x1024)");
                Assert.NotNull(body);
            }
            catch (Exception ex)
            {
                _output.WriteLine($"❌ ERROR: {ex.Message}");
                throw;
            }
        }

        [Fact]
        public void Test08_HomePage_ResponsiveDesign_Mobile()
        {
            try
            {
                // Arrange - Set mobile size
                _driver.Manage().Window.Size = new System.Drawing.Size(375, 667);
                _driver.Navigate().GoToUrl(BASE_URL);
                Thread.Sleep(2000);

                // Act
                var body = _driver.FindElement(By.TagName("body"));

                // Assert
                _output.WriteLine("✅ Page renders on mobile viewport (375x667)");
                Assert.NotNull(body);
            }
            catch (Exception ex)
            {
                _output.WriteLine($"❌ ERROR: {ex.Message}");
                throw;
            }
        }

        [Fact]
        public void Test09_Navigation_AllLinksAccessible()
        {
            try
            {
                // Arrange
                _driver.Navigate().GoToUrl(BASE_URL);
                Thread.Sleep(2000);

                // Act
                var allLinks = _driver.FindElements(By.TagName("a"));

                // Assert
                _output.WriteLine($"✅ Found {allLinks.Count} links on page");

                int workingLinks = 0;
                foreach (var link in allLinks)
                {
                    if (!string.IsNullOrEmpty(link.GetAttribute("href")))
                    {
                        workingLinks++;
                    }
                }

                _output.WriteLine($"✅ {workingLinks} links have href attributes");
                Assert.True(workingLinks > 0, "Page should have working links");
            }
            catch (Exception ex)
            {
                _output.WriteLine($"❌ ERROR: {ex.Message}");
                throw;
            }
        }

        [Fact]
        public void Test10_PageLoad_PerformanceCheck()
        {
            try
            {
                // Arrange
                var stopwatch = System.Diagnostics.Stopwatch.StartNew();

                // Act
                _driver.Navigate().GoToUrl(BASE_URL);
                stopwatch.Stop();

                // Assert
                var loadTime = stopwatch.ElapsedMilliseconds;
                _output.WriteLine($"✅ Page loaded in {loadTime}ms");

                Assert.True(loadTime < 10000, $"Page load time {loadTime}ms should be under 10 seconds");
            }
            catch (Exception ex)
            {
                _output.WriteLine($"❌ ERROR: {ex.Message}");
                throw;
            }
        }

        public void Dispose()
        {
            Thread.Sleep(1000); // Brief pause before closing
            _driver?.Quit();
            _driver?.Dispose();
        }
    }
}