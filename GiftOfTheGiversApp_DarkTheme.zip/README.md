\# Gift of the Givers Foundation - Disaster Alleviation Application

\# Gift of the Givers Foundation - Disaster Alleviation Application



\*\*Student Number\*\*: ST10268692  

\*\*Module\*\*: APPR6312 - Applied Programming  



---



\## 📋 Project Overview



A web application developed for the Gift of the Givers Foundation to manage disaster relief operations, coordinate volunteers, facilitate resource donations, and track relief efforts across South Africa.



---



\## 🛠️ Technologies Used



\- \*\*Framework\*\*: ASP.NET Core 8.0 MVC

\- \*\*Database\*\*: SQL Server / Azure SQL Database

\- \*\*Authentication\*\*: ASP.NET Core Identity

\- \*\*ORM\*\*: Entity Framework Core

\- \*\*Testing\*\*: xUnit, MSTest

\- \*\*Version Control\*\*: Azure DevOps Repos

\- \*\*CI/CD\*\*: Azure Pipelines (configured)

\- \*\*Deployment\*\*: Azure App Services (attempted)



---



\## 📁 Project Structure

```

GiftOfTheGiversApp/

│

├── DisasterAlleviationFoundation/              # Main Web Application

│   ├── Controllers/                            # MVC Controllers

│   │   ├── HomeController.cs

│   │   ├── DisasterIncidentController.cs

│   │   ├── DonationController.cs

│   │   └── VolunteerController.cs

│   │

│   ├── Models/                                 # Domain Models

│   │   ├── DisasterIncident.cs

│   │   ├── Donation.cs

│   │   └── Volunteer.cs

│   │

│   ├── ViewModels/                             # View Models

│   │   ├── DisasterIncidentViewModel.cs

│   │   ├── DonationViewModel.cs

│   │   └── VolunteerViewModel.cs

│   │

│   ├── Views/                                  # Razor Views

│   │   ├── Home/

│   │   ├── DisasterIncident/

│   │   ├── Donation/

│   │   └── Volunteer/

│   │

│   ├── Data/                                   # Database Context

│   │   └── ApplicationDbContext.cs

│   │

│   ├── Services/                               # Business Logic

│   │   ├── DisasterIncidentService.cs

│   │   ├── DonationService.cs

│   │   └── VolunteerService.cs

│   │

│   └── Program.cs                              # Application Entry Point

│

├── DisasterAlleviationFoundation.Tests/        # Unit \& Integration Tests

│   ├── UnitTests/

│   │   ├── DisasterIncidentTests.cs           # 6 unit tests

│   │   ├── DonationTests.cs                   # 6 unit tests

│   │   └── VolunteerTests.cs                  # 5 unit tests

│   │

│   └── IntegrationTests/

│       └── DatabaseIntegrationTests.cs        # 11 integration tests

│

├── DisasterAlleviationFoundation.PerformanceTests/  # Performance Tests

│   ├── LoadTests/

│   │   └── BasicLoadTests.cs                  # 3 load tests

│   │

│   └── StressTests/

│       └── BasicStressTests.cs                # 3 stress tests

│

├── azure-pipelines.yml                         # CI/CD Pipeline Configuration

└── README.md                                   # This file

```



---



\## ✨ Features Implemented



\### Part 1: Project Planning

✅ Azure Boards project setup  

✅ User stories, epics, and tasks defined  

✅ Sprint planning and organization  

✅ Database schema design (ERD)  

✅ Azure SQL Database optimization  



\### Part 2: Application Development

✅ \*\*User Registration \& Authentication\*\* - Secure login system using ASP.NET Identity  

✅ \*\*Disaster Incident Reporting\*\* - Users can report disasters with location and severity  

✅ \*\*Resource Donation Management\*\* - Track donations of food, supplies, and funds  

✅ \*\*Volunteer Management\*\* - Register volunteers and assign tasks  

✅ \*\*Git Repository\*\* - Complete version control with Azure Repos  

✅ \*\*Build Pipeline\*\* - Automated CI pipeline in Azure DevOps  



\### Part 3: Testing \& Quality Assurance

✅ \*\*Unit Testing\*\* - 17 comprehensive unit tests (100% pass rate)  

✅ \*\*Integration Testing\*\* - 11 database integration tests (100% pass rate)  

✅ \*\*Load Testing\*\* - Performance tests simulating 10-50 concurrent users  

✅ \*\*Stress Testing\*\* - Stress tests with gradual load increase and spike testing  

✅ \*\*UI Testing\*\* - 10-point functional UI test checklist  

✅ \*\*Usability Testing\*\* - User feedback from 5 user personas  

✅ \*\*Code Coverage\*\* - 70%+ code coverage achieved  



---



\## 🧪 Testing Summary



\### Test Statistics

\- \*\*Total Tests\*\*: 42 tests

\- \*\*Pass Rate\*\*: 100%

\- \*\*Code Coverage\*\*: 70%+

\- \*\*Test Execution Time\*\*: ~45 seconds



\### Test Breakdown

| Test Type | Count | Status | Coverage |

|-----------|-------|--------|----------|

| Unit Tests | 17 | ✅ PASS | Controllers, Models, Services |

| Integration Tests | 11 | ✅ PASS | Database operations |

| Load Tests | 3 | ✅ PASS | 10-50 concurrent users |

| Stress Tests | 3 | ✅ PASS | Gradual load, spikes, sustained |

| UI Tests | 10 | ✅ PASS | Navigation, forms, validation |



---



\## 🚀 How to Run the Application



\### Prerequisites

\- Visual Studio 2022 (or later)

\- .NET 8.0 SDK

\- SQL Server (LocalDB or full instance)

\- Azure DevOps account (for repo access)



\### Setup Instructions



1\. \*\*Clone the repository\*\*

```bash

&nbsp;  git clone https://ST10268692@dev.azure.com/ST10268692/GiftOfTheGiversApp/\_git/GiftOfTheGiversApp

&nbsp;  cd GiftOfTheGiversApp

```



2\. \*\*Open in Visual Studio\*\*

&nbsp;  - Double-click `DisasterAlleviationFoundation.sln`

&nbsp;  - Wait for NuGet packages to restore



3\. \*\*Update Database Connection\*\*

&nbsp;  - Open `appsettings.json`

&nbsp;  - Update `ConnectionStrings:DefaultConnection` with your SQL Server details



4\. \*\*Run Migrations\*\*

```bash

&nbsp;  # In Package Manager Console

&nbsp;  Update-Database

```



5\. \*\*Run the Application\*\*

&nbsp;  - Press `F5` in Visual Studio

&nbsp;  - Application will open at `https://localhost:7xxx`



---



\## 🧪 How to Run Tests



\### Run All Tests

```bash

dotnet test

```



\### Run Specific Test Projects

```bash

\# Unit \& Integration Tests

dotnet test DisasterAlleviationFoundation.Tests



\# Performance Tests

dotnet test DisasterAlleviationFoundation.PerformanceTests

```



\### Run Tests with Detailed Output

```bash

dotnet test --logger "console;verbosity=detailed"

```



\### Generate Code Coverage Report

```bash

dotnet test --collect:"XPlat Code Coverage"

```



---



\## 📊 Database Schema



\### Main Entities



\*\*DisasterIncidents\*\*

\- Id (PK)

\- Title

\- Description

\- Location

\- Severity

\- DateReported

\- Status



\*\*Donations\*\*

\- Id (PK)

\- DonorName

\- DonationType

\- Quantity

\- MonetaryValue

\- DateDonated



\*\*Volunteers\*\*

\- Id (PK)

\- Name

\- Email

\- Phone

\- Skills

\- Availability

\- TasksCompleted



\*\*Users\*\* (ASP.NET Identity)

\- User authentication and authorization



---



\## 🔄 CI/CD Pipeline



\### Azure Pipeline Configuration

\- \*\*Trigger\*\*: Automatic on push to `main` branch

\- \*\*Build Tasks\*\*: Restore → Build → Test → Publish

\- \*\*Test Execution\*\*: All unit and integration tests run automatically

\- \*\*Artifacts\*\*: Published for deployment



\### Pipeline Status

✅ Build pipeline configured and tested  

✅ Automated testing in pipeline  

❌ Deployment to Azure App Service blocked by subscription policy  



---



\## ☁️ Deployment (Attempted)


## 🌐 Live Deployment

**Application URL**: https://giftofgivers-cahzf4apebh7a3fp.southafricanorth-01.azurewebsites.net/

**Deployment Status**: ✅ Successfully deployed to Azure App Service  
**Region**: South Africa North  
**Platform**: Azure App Services  
**Deployment Date**: 31 October 2025

The application is live and fully functional on Azure!
---



\## 📦 Repository Information



\*\*Azure DevOps Repository\*\*:  

https://dev.azure.com/ST10268692/GiftOfTheGiversApp/\_git/GiftOfTheGiversApp





---



\## 📝 Documentation



All project documentation is available in the repository:

\- Complete Testing Report (PDF)

\- Deployment Blocked Explanation (PDF)

\- Test execution screenshots

\- Code coverage reports

\- Usability testing feedback



---



\## 👨‍💻 Development Team



\*\*Student\*\*: ST10268692  

\*\*Role\*\*: Full-Stack Developer, Tester, DevOps Engineer  

\*\*Institution\*\*: The Independent Institute of Education  

\*\*Module\*\*: APPR6312 - Applied Programming  



---



\## 📞 Support \& Contact



For questions about this project:

\- \*\*Repository Issues\*\*: Use Azure DevOps work items

\- \*\*Student Email\*\*: ST10268692@vcconnect.edu.za



---



\## 📄 License



This project is an academic submission for The IIE's Applied Programming module (APPR6312).  

All rights reserved © 2025



---



\## 🙏 Acknowledgments



\- \*\*Gift of the Givers Foundation\*\* - For the project inspiration

\- \*\*The IIE\*\* - For the academic framework and support

\- \*\*Azure DevOps\*\* - For development tools and platform

\- \*\*Microsoft\*\* - For .NET and Azure technologies



---



\## 📊 Project Statistics



\- \*\*Lines of Code\*\*: 5000+ (estimated)

\- \*\*Files\*\*: 50+ source files

\- \*\*Tests\*\*: 42 automated tests

\- \*\*Test Coverage\*\*: 70%+

\- \*\*Development Time\*\*: 45+ hours

\- \*\*Commits\*\*: 20+ commits with detailed messages



---





\*\*Version\*\*: 1.0.0  

\*\*Status\*\*: ✅ Complete (except Azure deployment due to policy restrictions)

\*\*Student Number\*\*: ST10268692  

\*\*Module\*\*: APPR6312 - Applied Programming  

\*\*Institution\*\*: The Independent Institute of Education  

\*\*Submission Date\*\*: October 2025



---




