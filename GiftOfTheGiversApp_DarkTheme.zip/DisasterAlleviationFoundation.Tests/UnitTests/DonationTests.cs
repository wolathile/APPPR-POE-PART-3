﻿using Xunit;
using DisasterAlleviationFoundation.Models;
using System;

namespace DisasterAlleviationFoundation.Tests.UnitTests
{
    public class DonationTests
    {
        [Fact]
        public void Donation_DefaultStatus_IsReceived()
        {
            // Arrange & Act
            var donation = new Donation();

            // Assert
            Assert.Equal("Received", donation.Status);
        }

        [Fact]
        public void Donation_CanSetDonationType()
        {
            // Arrange
            var donation = new Donation();

            // Act
            donation.DonationType = "Food";

            // Assert
            Assert.Equal("Food", donation.DonationType);
        }

        [Fact]
        public void Donation_IsAnonymous_DefaultsToFalse()
        {
            // Arrange & Act
            var donation = new Donation();

            // Assert
            Assert.False(donation.IsAnonymous);
        }

        [Fact]
        public void Donation_MonetaryAmount_CanBeSet()
        {
            // Arrange
            var donation = new Donation();

            // Act
            donation.MonetaryAmount = 1000.50m;

            // Assert
            Assert.Equal(1000.50m, donation.MonetaryAmount);
        }

        [Theory]
        [InlineData("Food")]
        [InlineData("Clothing")]
        [InlineData("Medical")]
        [InlineData("Monetary")]
        public void Donation_AcceptsValidDonationTypes(string donationType)
        {
            // Arrange
            var donation = new Donation();

            // Act
            donation.DonationType = donationType;

            // Assert
            Assert.Equal(donationType, donation.DonationType);
        }
    }
}