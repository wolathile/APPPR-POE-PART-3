﻿using Xunit;
using DisasterAlleviationFoundation.Models;
using System;

namespace DisasterAlleviationFoundation.Tests.UnitTests
{
    public class VolunteerTaskTests
    {
        [Fact]
        public void VolunteerTask_DefaultStatus_IsOpen()
        {
            // Arrange & Act
            var task = new VolunteerTask();

            // Assert
            Assert.Equal("Open", task.Status);
        }

        [Fact]
        public void VolunteerTask_AssignedVolunteers_DefaultsToZero()
        {
            // Arrange & Act
            var task = new VolunteerTask();

            // Assert
            Assert.Equal(0, task.AssignedVolunteers);
        }

        [Fact]
        public void VolunteerTask_CanSetTaskName()
        {
            // Arrange
            var task = new VolunteerTask();

            // Act
            task.TaskName = "Food Distribution";

            // Assert
            Assert.Equal("Food Distribution", task.TaskName);
        }

        [Fact]
        public void VolunteerTask_CanSetRequiredVolunteers()
        {
            // Arrange
            var task = new VolunteerTask();

            // Act
            task.RequiredVolunteers = 10;

            // Assert
            Assert.Equal(10, task.RequiredVolunteers);
        }
    }
}