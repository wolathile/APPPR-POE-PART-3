﻿using Xunit;
using DisasterAlleviationFoundation.Models;
using System;

namespace DisasterAlleviationFoundation.Tests.UnitTests
{
    public class VolunteerTests
    {
        [Fact]
        public void Volunteer_IsActive_DefaultsToTrue()
        {
            // Arrange & Act
            var volunteer = new Volunteer();

            // Assert
            Assert.True(volunteer.IsActive);
        }

        [Fact]
        public void Volunteer_RegistrationDate_IsSet()
        {
            // Arrange & Act
            var volunteer = new Volunteer();

            // Assert
            Assert.NotEqual(default(DateTime), volunteer.RegistrationDate);
        }

        [Fact]
        public void Volunteer_CanSetFullName()
        {
            // Arrange
            var volunteer = new Volunteer();

            // Act
            volunteer.FullName = "John Doe";

            // Assert
            Assert.Equal("John Doe", volunteer.FullName);
        }

        [Fact]
        public void Volunteer_CanSetEmail()
        {
            // Arrange
            var volunteer = new Volunteer();

            // Act
            volunteer.Email = "john@example.com";

            // Assert
            Assert.Equal("john@example.com", volunteer.Email);
        }

        [Theory]
        [InlineData("Weekdays")]
        [InlineData("Weekends")]
        [InlineData("Flexible")]
        public void Volunteer_AcceptsValidAvailability(string availability)
        {
            // Arrange
            var volunteer = new Volunteer();

            // Act
            volunteer.Availability = availability;

            // Assert
            Assert.Equal(availability, volunteer.Availability);
        }
    }
}