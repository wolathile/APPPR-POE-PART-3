﻿using Xunit;
using DisasterAlleviationFoundation.Models;
using System;

namespace DisasterAlleviationFoundation.Tests.UnitTests.ModelTests
{
    public class DisasterIncidentTests
    {
        [Fact]
        public void DisasterIncident_DefaultStatus_IsPending()
        {
            // Arrange
            var incident = new DisasterIncident();

            // Act
            var status = incident.Status;

            // Assert
            Assert.Equal("Pending", status);
        }

        [Fact]
        public void DisasterIncident_CanSetIncidentType()
        {
            // Arrange
            var incident = new DisasterIncident();

            // Act
            incident.IncidentType = "Flood";

            // Assert
            Assert.Equal("Flood", incident.IncidentType);
        }

        [Fact]
        public void DisasterIncident_DateReported_IsNotDefault()
        {
            // Arrange & Act
            var incident = new DisasterIncident();

            // Assert
            Assert.NotEqual(default(DateTime), incident.DateReported);
        }
    }
}