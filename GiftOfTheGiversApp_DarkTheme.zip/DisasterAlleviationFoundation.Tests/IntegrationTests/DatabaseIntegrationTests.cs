﻿using Xunit;
using Microsoft.EntityFrameworkCore;
using DisasterAlleviationFoundation.Data;
using DisasterAlleviationFoundation.Models;
using System.Linq;
using System.Threading.Tasks;

namespace DisasterAlleviationFoundation.Tests.IntegrationTests
{
    public class DatabaseIntegrationTests
    {
        private ApplicationDbContext GetInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: System.Guid.NewGuid().ToString())
                .Options;

            return new ApplicationDbContext(options);
        }

        [Fact]
        public async Task Database_CanAddAndRetrieveIncident()
        {
            // Arrange
            using var context = GetInMemoryDbContext();
            var incident = new DisasterIncident
            {
                IncidentType = "Flood",
                Location = "Test City",
                Description = "Integration test incident",
                SeverityLevel = 3,
                ContactNumber = "0123456789",
                ReportedByUserId = "test-user"
            };

            // Act
            context.DisasterIncidents.Add(incident);
            await context.SaveChangesAsync();

            // Assert
            var savedIncident = await context.DisasterIncidents.FirstOrDefaultAsync();
            Assert.NotNull(savedIncident);
            Assert.Equal("Flood", savedIncident.IncidentType);
            Assert.Equal("Test City", savedIncident.Location);
        }

        [Fact]
        public async Task Database_CanQueryIncidentsByType()
        {
            // Arrange
            using var context = GetInMemoryDbContext();
            context.DisasterIncidents.AddRange(
                new DisasterIncident { IncidentType = "Flood", Location = "City1", Description = "Test1", SeverityLevel = 1, ContactNumber = "111", ReportedByUserId = "user1" },
                new DisasterIncident { IncidentType = "Fire", Location = "City2", Description = "Test2", SeverityLevel = 2, ContactNumber = "222", ReportedByUserId = "user2" },
                new DisasterIncident { IncidentType = "Flood", Location = "City3", Description = "Test3", SeverityLevel = 3, ContactNumber = "333", ReportedByUserId = "user3" }
            );
            await context.SaveChangesAsync();

            // Act
            var floods = await context.DisasterIncidents
                .Where(i => i.IncidentType == "Flood")
                .ToListAsync();

            // Assert
            Assert.Equal(2, floods.Count);
            Assert.All(floods, f => Assert.Equal("Flood", f.IncidentType));
        }

        [Fact]
        public async Task Database_CanUpdateIncident()
        {
            // Arrange
            using var context = GetInMemoryDbContext();
            var incident = new DisasterIncident
            {
                IncidentType = "Fire",
                Location = "Update Test",
                Description = "Original",
                SeverityLevel = 2,
                ContactNumber = "0123456789",
                ReportedByUserId = "test-user"
            };
            context.DisasterIncidents.Add(incident);
            await context.SaveChangesAsync();

            // Act
            incident.Description = "Updated Description";
            incident.SeverityLevel = 4;
            await context.SaveChangesAsync();

            // Assert
            var updated = await context.DisasterIncidents.FindAsync(incident.IncidentId);
            Assert.Equal("Updated Description", updated.Description);
            Assert.Equal(4, updated.SeverityLevel);
        }

        [Fact]
        public async Task Database_CanDeleteIncident()
        {
            // Arrange
            using var context = GetInMemoryDbContext();
            var incident = new DisasterIncident
            {
                IncidentType = "Earthquake",
                Location = "Delete Test",
                Description = "To be deleted",
                SeverityLevel = 5,
                ContactNumber = "0123456789",
                ReportedByUserId = "test-user"
            };
            context.DisasterIncidents.Add(incident);
            await context.SaveChangesAsync();

            // Act
            context.DisasterIncidents.Remove(incident);
            await context.SaveChangesAsync();

            // Assert
            var count = await context.DisasterIncidents.CountAsync();
            Assert.Equal(0, count);
        }

        [Fact]
        public async Task Database_CanAddAndRetrieveDonation()
        {
            // Arrange
            using var context = GetInMemoryDbContext();
            var donation = new Donation
            {
                DonationType = "Food",
                Description = "Test donation",
                DonorName = "John Doe",
                DonorEmail = "john@test.com",
                DonorUserId = "user123",
                Quantity = 100
            };

            // Act
            context.Donations.Add(donation);
            await context.SaveChangesAsync();

            // Assert
            var saved = await context.Donations.FirstOrDefaultAsync();
            Assert.NotNull(saved);
            Assert.Equal("Food", saved.DonationType);
            Assert.Equal(100, saved.Quantity);
        }

        [Fact]
        public async Task Database_CanAddAndRetrieveVolunteer()
        {
            // Arrange
            using var context = GetInMemoryDbContext();
            var volunteer = new Volunteer
            {
                UserId = "user123",
                FullName = "Jane Doe",
                Email = "jane@test.com",
                PhoneNumber = "0123456789",
                Address = "123 Test St"
            };

            // Act
            context.Volunteers.Add(volunteer);
            await context.SaveChangesAsync();

            // Assert
            var saved = await context.Volunteers.FirstOrDefaultAsync();
            Assert.NotNull(saved);
            Assert.Equal("Jane Doe", saved.FullName);
            Assert.True(saved.IsActive);
        }
    }
}