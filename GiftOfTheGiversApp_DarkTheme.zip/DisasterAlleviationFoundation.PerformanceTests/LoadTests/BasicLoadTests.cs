﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace DisasterAlleviationFoundation.PerformanceTests.LoadTests
{
    public class BasicLoadTests
    {
        private readonly ITestOutputHelper _output;

        public BasicLoadTests(ITestOutputHelper output)
        {
            _output = output;
        }

        [Fact]
        public async Task LoadTest_Simple()
        {
            _output.WriteLine("Starting Load Test");
            
            using var client = new HttpClient();
            var response = await client.GetAsync("https://www.google.com");
            
            _output.WriteLine($"Response: {response.StatusCode}");
            Assert.True(response.IsSuccessStatusCode);
        }

        [Fact]
        public async Task LoadTest_10Users()
        {
            var results = new List<bool>();
            var tasks = new List<Task>();
            
            _output.WriteLine("Testing 10 concurrent users");
            
            for (int i = 0; i < 10; i++)
            {
                tasks.Add(Task.Run(async () =>
                {
                    using var client = new HttpClient();
                    var response = await client.GetAsync("https://www.google.com");
                    lock (results)
                    {
                        results.Add(response.IsSuccessStatusCode);
                    }
                }));
            }
            
            await Task.WhenAll(tasks);
            
            var successRate = results.Count(r => r) * 100.0 / results.Count;
            _output.WriteLine($"Success Rate: {successRate}%");
            
            Assert.True(successRate >= 80);
        }

        [Fact]
        public async Task LoadTest_PerformanceCheck()
        {
            var sw = Stopwatch.StartNew();
            
            using var client = new HttpClient();
            var response = await client.GetAsync("https://www.google.com");
            
            sw.Stop();
            
            _output.WriteLine($"Response time: {sw.ElapsedMilliseconds}ms");
            Assert.True(sw.ElapsedMilliseconds < 10000);
        }
    }
}