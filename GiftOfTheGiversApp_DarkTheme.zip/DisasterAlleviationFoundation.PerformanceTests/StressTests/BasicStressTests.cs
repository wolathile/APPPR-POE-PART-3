﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace DisasterAlleviationFoundation.PerformanceTests.StressTests
{
    public class BasicStressTests
    {
        private readonly ITestOutputHelper _output;

        public BasicStressTests(ITestOutputHelper output)
        {
            _output = output;
        }

        [Fact]
        public async Task StressTest_Gradual()
        {
            var levels = new[] { 5, 10, 20, 30 };
            
            foreach (var userCount in levels)
            {
                _output.WriteLine($"Testing {userCount} users");
                
                var tasks = new List<Task>();
                var successCount = 0;
                
                for (int i = 0; i < userCount; i++)
                {
                    tasks.Add(Task.Run(async () =>
                    {
                        using var client = new HttpClient();
                        var response = await client.GetAsync("https://www.google.com");
                        if (response.IsSuccessStatusCode)
                        {
                            System.Threading.Interlocked.Increment(ref successCount);
                        }
                    }));
                }
                
                await Task.WhenAll(tasks);
                
                var rate = successCount * 100.0 / userCount;
                _output.WriteLine($"  Success: {successCount}/{userCount} ({rate:F1}%)");
            }
        }

        [Fact]
        public async Task StressTest_Spike()
        {
            _output.WriteLine("Normal load");
            await TestLoad(5);
            
            _output.WriteLine("SPIKE!");
            await TestLoad(30);
            
            _output.WriteLine("Recovery");
            await TestLoad(5);
        }

        [Fact]
        public async Task StressTest_Sustained()
        {
            var duration = TimeSpan.FromSeconds(10);
            var sw = Stopwatch.StartNew();
            var total = 0;
            var success = 0;
            
            while (sw.Elapsed < duration)
            {
                using var client = new HttpClient();
                try
                {
                    var response = await client.GetAsync("https://www.google.com");
                    total++;
                    if (response.IsSuccessStatusCode) success++;
                }
                catch
                {
                    total++;
                }
            }
            
            var rate = success * 100.0 / total;
            _output.WriteLine($"Results: {success}/{total} ({rate:F1}%)");
            
            Assert.True(rate >= 60);
        }

        private async Task TestLoad(int users)
        {
            var tasks = new List<Task>();
            var success = 0;
            
            for (int i = 0; i < users; i++)
            {
                tasks.Add(Task.Run(async () =>
                {
                    using var client = new HttpClient();
                    var response = await client.GetAsync("https://www.google.com");
                    if (response.IsSuccessStatusCode)
                    {
                        System.Threading.Interlocked.Increment(ref success);
                    }
                }));
            }
            
            await Task.WhenAll(tasks);
            
            var rate = success * 100.0 / users;
            _output.WriteLine($"  {success}/{users} ({rate:F1}%)");
        }
    }
}